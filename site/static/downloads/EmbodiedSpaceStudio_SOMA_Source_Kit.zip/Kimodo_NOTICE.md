# Kimodo notice

Embodied Space Studio interoperates with Kimodo through the separately installed KimodoBridge service. The Fab plugin does not include this SOMA Source Kit, the Kimodo Python runtime, model checkpoints, text encoder, or third-party visualization and robot assets.

The SOMA glTF files in this separately distributed Source Kit are derived from the Kimodo project and are distributed under the Apache License 2.0 included in `Kimodo_LICENSE.txt`.

## Citation

Davis Rempe et al., “Kimodo: Scaling Controllable Human Motion Generation,” arXiv:2603.15546, 2026. https://arxiv.org/abs/2603.15546
