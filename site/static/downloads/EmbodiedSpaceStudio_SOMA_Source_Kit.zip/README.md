# Embodied Space Studio SOMA Source Kit

This kit is distributed separately from the Embodied Space Studio Fab plugin.

## Files

- `SK_KimodoSOMA.gltf`: original Kimodo/SOMA source mesh and skeleton selected from the Generate tab.
- `SK_KimodoSOMA_Rooted.gltf`: matching rooted source used by **Generate / Refresh Rooted SOMA Source** in the Export tab.
- `Kimodo_LICENSE.txt` and `Kimodo_NOTICE.md`: license and attribution for the SOMA source files in this kit.
- `SHA256SUMS.txt`: integrity hashes for the distributed source and legal files.

## Import workflow

1. Keep both glTF files together in the same folder.
2. In Unreal Editor, open **Window > Kimodo Motion Authoring**.
3. In the Generate tab, click **Choose & Import Kimodo SOMA Mesh / Skeleton** and select `SK_KimodoSOMA.gltf`.
4. In the Export tab, select the target character and click **Generate / Refresh Rooted SOMA Source**. The plugin finds `SK_KimodoSOMA_Rooted.gltf` beside the selected original file and imports or refreshes the rooted project assets.

Do not copy this kit into the Fab plugin directory. The imported Unreal assets are created in the user's project Content directory.
